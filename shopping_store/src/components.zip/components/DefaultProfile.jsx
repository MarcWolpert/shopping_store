const DefaultProfile = () => {
	return <p>Oh, nothing to see here!</p>;
};

export default DefaultProfile;
